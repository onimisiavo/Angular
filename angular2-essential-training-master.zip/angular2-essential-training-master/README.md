# UPDATE
The repository for the **Angular Essential Training** course can be found at https://github.com/coursefiles/angular2-essential-training.  

*This is the old location of the code and is no longer being maintained*
